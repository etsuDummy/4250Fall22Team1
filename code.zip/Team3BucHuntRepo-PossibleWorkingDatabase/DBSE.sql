/*****************************************************
File name: DBSE.sql
Created By: Philip Gaver & Tanner Collins
Creation Date: 11/16/2022
Last Modified: 11/16/2022
Summary: Create and populate Tasks table for BucHunt
*****************************************************/

--Create database
CREATE DATABASE [HuntDB]
GO

USE [HuntDB]
GO
-- Drop existing table
DROP TABLE Tasks;
DROP TABLE PhoneNumbers;

-- Create table to contain task info (TaskID, Location, Question, Answer)
CREATE TABLE Tasks
(
	TaskID int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	Location varchar(50),
	Question varchar(200),
	Answer varchar(25)
);

-- Insert task 1
INSERT INTO Tasks (Location, Question, Answer)
	VALUES ('Flagpoles next to Brooks Gym (Memorial Hall)', 
			'When was the leadership and excellence memorial for our fallen soldier students dedicated?', 
			'November 11, 2003');

-- Insert task 2
INSERT INTO Tasks (Location, Question, Answer)
	VALUES ('Sam Wilson Hall', 
			'Who is listed on the bench outside the front of Sam Wilson Hall?', 
			'Douglas Dotterweich');


-- Insert task 3
INSERT INTO Tasks (Location, Question, Answer)
	VALUES ('ETSU Book Store', 
			'How many visible pillars are in the ETSU Book Store?', 
			'3');

-- Insert task 4
INSERT INTO Tasks (Location, Question, Answer)
	VALUES ('Special Services Lab', 
			'What room number is the Special Services Lab in Sherrod Library?', 
			'318');

-- Insert task 5
INSERT INTO Tasks (Location, Question, Answer)
	VALUES ('Sherrod Library', 
			'How many printers are available to students on the first floor of the Sherrod Library?', 
			'5');

-- Insert task 6
INSERT INTO Tasks (Location, Question, Answer)
	VALUES ('Brown Hall', 
			'Who is the third author of the paper posted on the wall on the fourth floor of Brown Hall called "Purification and Characterization of Bioactive Metabolites?"', 
			'Sean Fox');

-- Insert task 7
INSERT INTO Tasks (Location, Question, Answer)
	VALUES ('Tri-Hall Field', 
			'How many swings are located within Tri-Hall field?', 
			'4');

-- Insert task 8
INSERT INTO Tasks (Location, Question, Answer)
	VALUES ('Counseling Center', 
			'What room number is the counseling center in the Culp Center?', 
			'326');

-- Insert task 9
INSERT INTO Tasks (Location, Question, Answer)
	VALUES ('Culp Center', 
			'How many restaurants are in the Culp Center?', 
			'5');

-- Insert task 10
INSERT INTO Tasks (Location, Question, Answer)
	VALUES ('ETSU Health Clinic', 
			'What floor is the health clinic located in Roy S. Nicks Halls?', 
			'1');

-- Test to ensure all tasks are in table
-- SELECT * FROM Tasks;

-- Create table to contain phone number info (UserID, PhoneNumber)
CREATE TABLE PhoneNumbers
(
	UserID int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	PhoneNumber varchar(20)
);

-- The following insertions are test phone numbers for us to test the database against
INSERT INTO PhoneNumbers(PhoneNumber)
	VALUES('4233303513');

INSERT INTO PhoneNumbers(PhoneNumber)
	VALUES('0123456789');

INSERT INTO PhoneNumbers(PhoneNumber)
	VALUES('5295829384');



	USE [HuntDB]
GO

CREATE PROCEDURE [spAddPhoneNumber]
	@PhoneNumber varchar(20) AS
	BEGIN
		DECLARE @UserID as Int;
		INSERT INTO PhoneNumbers(PhoneNumber)
		VALUES (@PhoneNumber);
		SET @UserID = SCOPE_IDENTITY();
		SELECT @UserID AS pubID;
	END
GO

CREATE PROCEDURE [spUpdatePhoneNumber]
	@UserID		 Int,
	@PhoneNumber varchar(20)
	AS
		UPDATE PhoneNumbers
		SET [PhoneNumber] = @PhoneNumber
		WHERE [UserID] = @UserID


SELECT * FROM dbo.PhoneNumbers;
